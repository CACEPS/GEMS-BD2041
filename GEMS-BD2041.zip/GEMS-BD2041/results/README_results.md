After running scripts/run_all.sh (or .bat), copy DyCGE_summary.csv
and any per run DyCGE_results.csv exports into this folder. The
summary file feeds Tables 6 to 8, A12, and A8, and supplies the
anchor constants for scripts/mc_surrogate.py.
