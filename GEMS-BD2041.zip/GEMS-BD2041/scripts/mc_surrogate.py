"""Surrogate Monte Carlo for the DyCGE Vision 2041 audit.
Propagates documented sensitivity ranges (Supplementary Table A12,
Section S7) through the calibrated response surface. Seed 2041.
Reproduces main text Table 8 and Figure 8.
Requires numpy. Run: python mc_surrogate.py
"""
import numpy as np

rng = np.random.default_rng(2041)
N = 10000
PC_BAU_MID, PC_REF_MID = 7800.0, 11000.0
CROSS_REF_C, CROSS_BAU_C = 2055.0, 2062.5

e_bau = rng.uniform(-0.042, 0.038, N)
e_ref = rng.uniform(-0.051, 0.046, N)
t_bau = rng.uniform(-0.015, 0.015, N)
t_ref = rng.uniform(-0.040, 0.040, N)
fv = rng.choice([0, 1, 2], size=N, p=[0.25, 0.50, 0.25])
f_inc = np.where(fv == 0, 0.07, np.where(fv == 1, 0.0, -0.06))
f_yr = np.where(fv == 0, -4.0, np.where(fv == 1, 0.0, 3.5))

inc_bau = PC_BAU_MID * (1 + e_bau) * (1 + t_bau) * (1 + f_inc)
inc_ref = PC_REF_MID * (1 + e_ref) * (1 + t_ref) * (1 + f_inc)
cross_ref = CROSS_REF_C + f_yr + rng.uniform(-2.5, 2.5, N) + rng.uniform(-1.5, 1.5, N)
cross_bau = CROSS_BAU_C + 0.9 * f_yr + rng.uniform(-2.5, 2.5, N) + rng.uniform(-1.0, 1.0, N)

def q(x, p):
    return np.percentile(x, p)

print("BAU income 2041: median {:.0f} | 5-95: {:.0f}-{:.0f}".format(np.median(inc_bau), q(inc_bau,5), q(inc_bau,95)))
print("Reform income 2041: median {:.0f} | 5-95: {:.0f}-{:.0f}".format(np.median(inc_ref), q(inc_ref,5), q(inc_ref,95)))
print("Reform crossing: median {:.0f} | 5-95: {:.0f}-{:.0f}".format(np.median(cross_ref), q(cross_ref,5), q(cross_ref,95)))
print("BAU crossing: median {:.0f} | 5-95: {:.0f}-{:.0f}".format(np.median(cross_bau), q(cross_bau,5), q(cross_bau,95)))
print("P(target by 2041, reform): {:.3f}".format((inc_ref >= 12500).mean()))
print("P(crossing by 2056, reform): {:.3f}".format((cross_ref <= 2056).mean()))
