@echo off
REM Full replication batch (Windows). Run from the model\ folder.
set MODEL=DyCGE_Vision2041_AllInOne.gms
echo SCEN,ELAST,FERT,TFPSCALE,PC2041,YRUMIC,YRHIC> DyCGE_summary.csv
for %%S in (1 2 3 4 5 6 7 8 9) do gams %MODEL% --SCEN=%%S --ELAST=2 --FERT=2 --TFPSCALE=1.0
for %%S in (1 2) do for %%E in (1 3) do gams %MODEL% --SCEN=%%S --ELAST=%%E --FERT=2 --TFPSCALE=1.0
for %%S in (1 9) do for %%F in (1 3) do gams %MODEL% --SCEN=%%S --ELAST=2 --FERT=%%F --TFPSCALE=1.0
for %%T in (0.5 1.5) do gams %MODEL% --SCEN=9 --ELAST=2 --FERT=2 --TFPSCALE=%%T
echo Done. See DyCGE_summary.csv.
