#!/usr/bin/env bash
# Full replication batch for the DyCGE Vision 2041 audit.
# Requires GAMS 25.x with CONOPT on PATH. Run from the model/ folder.
set -e
MODEL=DyCGE_Vision2041_AllInOne.gms
echo "SCEN,ELAST,FERT,TFPSCALE,PC2041,YRUMIC,YRHIC" > DyCGE_summary.csv
# Core scenarios and decomposition (Tables 6 and 7)
for S in 1 2 3 4 5 6 7 8 9; do
  gams "$MODEL" --SCEN=$S --ELAST=2 --FERT=2 --TFPSCALE=1.0
done
# Elasticity robustness (Table A12) on BAU and target
for S in 1 2; do for E in 1 3; do
  gams "$MODEL" --SCEN=$S --ELAST=$E --FERT=2 --TFPSCALE=1.0
done; done
# Fertility variants (Section 5.4) on BAU and partial reform
for S in 1 9; do for F in 1 3; do
  gams "$MODEL" --SCEN=$S --ELAST=2 --FERT=$F --TFPSCALE=1.0
done; done
# TFP linkage sweep (Table A8) on the partial reform path
for T in 0.5 1.5; do
  gams "$MODEL" --SCEN=9 --ELAST=2 --FERT=2 --TFPSCALE=$T
done
echo "Done. Summary in DyCGE_summary.csv; trajectories in DyCGE_results.csv (last run)."
