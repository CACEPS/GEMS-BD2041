SAM_BD_2019.xlsx: 4 activities, 5 commodities, 2 labour, 2 capital,
4 households, firms, government, ROW. Source: BBS 2015 IO table
updated to FY2019; cross entropy balancing (Robinson et al., 2001).
The balanced SAM used by the model is embedded in
model/DyCGE_Vision2041_AllInOne.gms (SECTION 2) with estimation
rules E1 to E9 documented in the file header.
