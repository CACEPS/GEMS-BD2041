Scenario drivers are generated in SECTION 7 of the all in one .gms
file. Codes: 1 BAU, 2 Vision 2041 target, 3 Downside, 4 to 8 single
lever runs SL1 to SL5, 9 Partial reform. Annual paths match
Supplementary Tables A9 (BAU), A10 (target), and A11 (downside).
Fertility variants and the TFP coefficient sweep compose through the
--FERT and --TFPSCALE switches.
