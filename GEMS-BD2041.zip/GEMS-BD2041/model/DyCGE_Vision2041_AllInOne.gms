$TITLE Bangladesh DyCGE Model - All-in-one replication file (Vision 2041)
* =====================================================================
* DyCGE  --  Bangladesh Economy Dynamic CGE Model  --  ALL-IN-ONE FILE
* Companion to: "Auditing long run development targets in emerging
* economies: A dynamic CGE assessment of Bangladesh's Vision 2041"
* This version implements the partially endogenous TFP linkage of
* Supplementary Section S5.1:
*   gA(j,t) = g0(j) + 0.15*[FDIshare(t-1)-FDIshare(0)] + 0.30*gH(t)
* Static core: PEP standard single-country CGE model V2.0
*   (Decaluwe, Lemelin, Maisonnave & Robichaud, 2013a).
* Dynamic extension: recursive, consistent with PEP-1-t V2.1
*   (Decaluwe et al., 2013b), with author modifications.
* Authors: [withheld for double-anonymous review]
* Target platform: GAMS 25.0.x classic IDE | NLP solver CONOPT
* =====================================================================
$ONTEXT
=======================================================================
README  (all-in-one: readme + data + calibration + model + scenarios)
=======================================================================

1. CONTENTS
   SECTION 0  Run controls: scenario switch SCEN (1-9), elasticity
              set ELAST, fertility variant FERT, TFP sweep TFPSCALE
   SECTION 1  Sets (PEP V2.0 account structure: 4 industries,
              5 commodities, 2 labour, 2 capital, 4 households)
   SECTION 2  Built-in balanced Social Accounting Matrix,
              FY2017-18 accounts updated to the FY2019 base
              (million USD, current prices)
   SECTION 3  Data-completion assumptions (documented, editable)
   SECTION 4  Elasticities (PEP-1-t V2.1 defaults, VAL_PAR.xls)
   SECTION 5  Calibration of all share and scale parameters
   SECTION 6  Variables and equations (within-period core)
   SECTION 7  Recursive-dynamic loop, 32 periods FY2019-FY2050,
              scenario driver paths, and the S5.1 partially
              endogenous TFP linkage
   SECTION 8  Reporting: growth, per capita income, income
              threshold crossing years; CSV output

2. HOW TO RUN (GAMS 25.0.1 classic IDE)
   - Open the file in the IDE and press F9. Default scenario = BAU.
   - Command line (core scenarios):
       gams DyCGE_Vision2041_AllInOne.gms --SCEN=1   (BAU)
       gams DyCGE_Vision2041_AllInOne.gms --SCEN=2   (VISION 2041)
       gams DyCGE_Vision2041_AllInOne.gms --SCEN=3   (DOWNSIDE)
   - Single lever decomposition (main text Table 6):
       --SCEN=4  SL1 FDI to 4 percent of GDP
       --SCEN=5  SL2 TFP growth to ~1.5 percent
       --SCEN=6  SL3 population growth to near zero
       --SCEN=7  SL4 direct tax share doubled
       --SCEN=8  SL5 interest spread to 2.5 points
       --SCEN=9  PARTIAL reform (half of each lever)
   - Robustness switches (compose with any SCEN):
       --ELAST=1|2|3      elasticity set low/central/high (Table A12)
       --FERT=1|2|3       UN fertility variant low/medium/high
       --TFPSCALE=0.5|1.0|1.5  S5.2 sweep on linkage coefficients
   - Full replication batch: scripts/run_all.sh (Linux/macOS) or
     scripts/run_all.bat (Windows). Each run appends one line to
     DyCGE_summary.csv (SCEN,ELAST,FERT,TFPSCALE,PC2041,YRUMIC,YRHIC).
     Full trajectories per run are in DyCGE_results.csv.
   - The mc_surrogate.py anchors (BAU and reform midpoints, central
     crossing years) come from the SCEN=1 and SCEN=9 summary lines.
   - Solver: the file requests CONOPT. If your licence lacks
     CONOPT, delete the "NLP=CONOPT" entry in the OPTION line and
     the default NLP solver is used.
   - Outputs: displays in the .lst file plus DyCGE_results.csv.

3. DATA PROVENANCE AND ESTIMATED CELLS
   The SAM is organised on the PEP standard model V2.0 account
   framework. Raw entries come from SAM-V2_0.xls, compiled from
   the FY2017-18 national accounts (BBS) and the 2015 input-output
   table (BBS, 2017). Cells unavailable from published sources
   were estimated by the authors and are marked "// EST" in
   SECTION 2. Estimation rules:
   E1  Tax-account pass-through: direct, payroll, capital and
       land tax accounts remit full receipts to government.
   E2  Capital and land tax receipts allocated across industries
       in proportion to factor payments (totals 5600.00 and
       2400.07 from the raw matrix).
   E3  Factor income accruing abroad added by scaling industry
       factor payments (3818.27 capital, 1644.13 land).
   E4  Household consumption of services (missing in raw SAM) set
       to SERSHARE of each household budget; other consumption
       rescaled proportionally; budgets unchanged.
   E5  Household account gaps closed by remittances from abroad
       (deficits) or savings (surpluses); firm and government
       accounts close through savings (government savings may be
       negative).
   E6  Domestic supply DS(J,I) equals industry output minus
       exports, mapped by concordance; IND output split between
       FOOD and OTHIND in proportion to total demand.
   E7  Government purchases the full output of the public
       administration commodity (PEP convention).
   E8  Investment demand follows basket shares INVSH; imports are
       the residual between demand and domestic supply; excess
       supply is absorbed by inventory changes (VSTK).
   E9  Four stub cells below USD 16 million (TI and TM accounts,
       export margins) folded into direct-tax and export-tax
       accounts.
   The completed matrix balances every account to below USD 0.005
   million; the file aborts if the embedded data are edited into
   imbalance. To replace EST cells with observed BBS data,
   rebalance first (cross-entropy, Robinson et al., 2001) or
   re-apply rules E1-E8.

4. KNOWN DATA CAVEATS (inherited from the raw SAM; review)
   C1  Household factor-income cells are low relative to spending;
       rule E5 therefore yields remittances near USD 118 billion,
       far above observed inflows (about 15 billion). Update the
       factor-allocation cells from BBS to correct.
   C2  Large capital and land payments in public administration,
       combined with E7, produce a government deficit (SG about
       -62 billion) well above the observed deficit.
   C3  Imports are residual-determined and therefore high.
   C4  Per capita income is anchored to the official FY2019 per
       capita GDP (USD 1856) and grown at model rates; threshold
       crossings depend on growth rates, not on SAM levels.

5. MODEL STRUCTURE (within each period)
   Leontief output = value added + intermediates; CES value added
   over composite labour and composite capital; CES labour and
   capital nests; capital sector-specific within the period;
   labour mobile with flexible wages; LES household demand
   (Frisch -1.5); CET allocation of IND output between FOOD and
   OTHIND; commodity-level CET between exports and domestic
   sales; constant-elasticity world export demand; Armington CES
   between imports and domestic goods; taxes: direct, payroll,
   capital, production, export. Closure: exchange rate is the
   numeraire (all values in USD, world prices fixed); foreign
   savings exogenous; real government consumption and transfers
   exogenous; savings-driven investment allocated across sectors
   by relative returns; Walras residual reported on the AGR
   market (LEON).
   Between periods: K(t+1)=(1-delta)K(t)+IND(t); labour and
   population follow scenario demographics; sectoral TFP follows
   the partially endogenous linkage of Supplementary S5.1,
   gA(j,t) = g0(j) + 0.15*[FDIshare(t-1)-FDIshare(0)] + 0.30*gH(t),
   so scenario TFP paths are generated by their FDI and human
   capital drivers rather than imposed; world demand, transfers,
   remittances, inventories, government consumption and foreign
   savings are indexed.
   The baseline drifts g0(j) (parameter GTFP0(J) in the code) and the human capital growth path
   gH(t) are stylised calibrations chosen to reproduce the paper's
   headline aggregate TFP paths (about 0.8 percent BAU, about 1.5
   percent target). Replace them with estimated values in
   SECTION 7 as data allow.

6. SCENARIOS (paper Section 3.3)
   BAU      FDI share ~1.0-1.3 percent, gH 1.0 percent (implied
            TFP ~0.8 percent), population growth 1.30 declining
            to 1.00 percent, constant policy.
   VISION   FDI share rising to 4 percent by 2041, gH rising to
            2.0 percent (implied TFP ~1.5 percent), population
            growth to near zero by 2041, foreign savings scale to
            2.5x, direct-tax scale doubling, interest rate 10 to
            7.5 percent.
   DOWNSIDE FDI share 0.8 percent, gH 0.8 percent, minus nn()
            shocks in periods 1-10 (implied TFP below 0.8
            percent), population growth flat at 1.3 percent.
   TFP columns in Supplementary Tables A9-A11 are the outputs of
   the S5.1 rule under these drivers, not independent inputs.

7. CITATION
   Cite the companion article plus: Decaluwe, Lemelin, Maisonnave
   and Robichaud (2013a, 2013b), PEP-1-1 V2.0 and PEP-1-t V2.1,
   Partnership for Economic Policy; Robinson, Cattaneo and
   El-Said (2001), Economic Systems Research 13(1), 47-64.

8. VERSION NOTES
   Classic GAMS syntax only (no embedded code, no $onEnd); solved
   period by period; each period is an NLP with constant
   objective. Every equation was verified to reproduce the base
   year exactly at calibration.
=======================================================================
$OFFTEXT
$EOLCOM //

* =====================================================================
* SECTION 0: RUN CONTROLS
* =====================================================================
$IF NOT SET SCEN     $SET SCEN 1
$IF NOT SET ELAST    $SET ELAST 2
$IF NOT SET FERT     $SET FERT 2
$IF NOT SET TFPSCALE $SET TFPSCALE 1.0
SCALAR SCEN "1=BAU 2=VISION 3=DOWNSIDE 4=SL1_FDI 5=SL2_TFP 6=SL3_POP 7=SL4_TAX 8=SL5_SPREAD 9=PARTIAL"
 / %SCEN% /;
SCALAR ELAST "Elasticity set, Table A12: 1=low 2=central 3=high" / %ELAST% /;
SCALAR FERT  "UN fertility variant, Section 5.4: 1=low 2=medium 3=high" / %FERT% /;
SCALAR TFPSCALE "S5.2 sweep: scale on TFP linkage coefficients" / %TFPSCALE% /;
OPTION LIMROW=0, LIMCOL=0, SOLPRINT=OFF, DECIMALS=2, NLP=CONOPT;

* =====================================================================
* SECTION 1: SETS (PEP standard model V2.0 account structure)
* =====================================================================
SET AC "All SAM accounts"
/ USK, SK, CAP, LAND
  HRP, HUP, HRR, HUR, FIRM, GVT, ROW
  TD, TUSK, TSK, TCAP, TLAND
  JAGR, JIND, JSER, JADM
  CAGR, CFOOD, COTHIND, CSER, CADM
  XAGR, XFOOD, XOTHIND, XSER
  INV, VSTK /;
ALIAS (AC,ACJ);

SET J(AC) "Industries" / JAGR, JIND, JSER, JADM /;
SET I(AC) "Commodities" / CAGR, CFOOD, COTHIND, CSER, CADM /;
SET I1(I) "Commodities except agriculture" / CFOOD, COTHIND, CSER, CADM /;
SET L(AC) "Labour" / USK, SK /;
SET K(AC) "Capital" / CAP, LAND /;
SET H(AC) "Households" / HRP, HUP, HRR, HUR /;
SET XX(AC) "Export accounts" / XAGR, XFOOD, XOTHIND, XSER /;
ALIAS (J,JJ); ALIAS (I,II); ALIAS (H,HH); ALIAS (L,LL); ALIAS (K,KK);

SET MXI(XX,I) "Export account to commodity map"
/ XAGR.CAGR, XFOOD.CFOOD, XOTHIND.COTHIND, XSER.CSER /;

SET TIME "Periods: 1*32 = FY2019-FY2050" / 1*32 /;

* =====================================================================
* SECTION 2: BALANCED SOCIAL ACCOUNTING MATRIX (million USD)
* Row = receipts, column = payments. "// EST" marks author-estimated
* cells (rules E1-E9 in the README).
* =====================================================================
PARAMETER SAM(AC,ACJ) "Balanced SAM, FY2017-18 base updated to FY2019" /
  TCAP.JADM  2117.8653   // EST
  TCAP.JAGR  670.4371   // EST
  TCAP.JIND  1768.7781   // EST
  TCAP.JSER  1042.9195   // EST
  FIRM.GVT  1378.9300
  FIRM.ROW  40571.5600
  GVT.TCAP  5600.0012
  GVT.TLAND  2400.0685
  GVT.ROW  3123.4067   // EST
  GVT.TSK  160.0000   // EST
  GVT.TD  12620.3834   // EST
  GVT.TUSK  1753.0000   // EST
  GVT.JADM  112.0000
  GVT.JAGR  295.2900
  GVT.JIND  3134.0000
  GVT.JSER  1871.0000
  GVT.XAGR  751.2671   // EST
  GVT.XFOOD  804.9566
  GVT.XOTHIND  303.3214   // EST
  GVT.XSER  1277.0621
  HRP.FIRM  19.6981
  HRP.GVT  1431.8041
  HRP.ROW  45307.5165   // EST
  HRP.CAP  4831.2983
  HRP.LAND  9848.0049
  HRP.SK  3534.1728
  HRP.USK  12766.0590
  HRR.FIRM  7.5591
  HRR.GVT  549.4492
  HRR.ROW  0.0010
  HRR.CAP  11840.5936
  HRR.LAND  47047.8583
  HRR.SK  612.0647
  HRR.USK  1467.7063
  HUP.FIRM  21.1262
  HUP.GVT  1535.6078
  HUP.ROW  49305.7296   // EST
  HUP.CAP  8924.6668
  HUP.LAND  8943.1147
  HUP.SK  305.8226
  HUP.USK  14506.9167
  HUR.FIRM  33.5167
  HUR.GVT  2436.2390
  HUR.ROW  23479.7652   // EST
  HUR.CAP  27892.2560
  HUR.LAND  46631.9177
  HUR.SK  22037.8914
  HUR.USK  6017.8093
  TLAND.JADM  907.6830   // EST
  TLAND.JAGR  287.3386   // EST
  TLAND.JIND  758.0699   // EST
  TLAND.JSER  446.9785   // EST
  ROW.GVT  2.2500
  ROW.HRP  14.7997
  ROW.HRR  5.6793
  ROW.HUP  15.8727
  ROW.HUR  25.1820
  ROW.CFOOD  50455.7181   // EST
  ROW.COTHIND  131396.5006   // EST
  ROW.CSER  513.9084   // EST
  ROW.CAP  3818.2654
  ROW.LAND  1644.1346
  TSK.JAGR  160.0000
  TD.FIRM  4391.7000
  TD.HRP  3036.0384   // EST
  TD.HRR  346.6420   // EST
  TD.HUP  3424.6455   // EST
  TD.HUR  1421.3575   // EST
  TUSK.JAGR  1300.0000
  TUSK.JIND  453.0000
  CADM.GVT  84797.0448   // EST
  CAGR.HRP  5486.2166   // EST
  CAGR.HRR  2105.3141   // EST
  CAGR.HUP  5883.9593   // EST
  CAGR.HUR  9334.8908   // EST
  CAGR.JAGR  4311.6500
  CAGR.JIND  11582.2000
  CAGR.JSER  2103.9200
  CAGR.INV  3017.6735   // EST
  CAGR.VSTK  2180.0399   // EST
  CFOOD.HRP  5139.8287   // EST
  CFOOD.HRR  1972.3785   // EST
  CFOOD.HUP  5512.4588   // EST
  CFOOD.HUR  8745.5182   // EST
  CFOOD.JADM  332.3700
  CFOOD.JAGR  3246.5400
  CFOOD.JIND  59469.5200
  CFOOD.JSER  11646.7700
  CFOOD.INV  6035.3470   // EST
  COTHIND.HRP  31142.7394   // EST
  COTHIND.HRR  11950.6491   // EST
  COTHIND.HUP  33400.5426   // EST
  COTHIND.HUR  52990.1951   // EST
  COTHIND.JADM  2606.0400
  COTHIND.JAGR  3157.2700
  COTHIND.JIND  34976.7400
  COTHIND.JSER  16047.2500
  COTHIND.INV  45265.1022   // EST
  CSER.GVT  4204.8600
  CSER.HRP  17900.9077   // EST
  CSER.HRR  6869.2893   // EST
  CSER.HUP  19198.6975   // EST
  CSER.HUR  30458.8303   // EST
  CSER.JADM  113.3800
  CSER.JAGR  178.8400
  CSER.JIND  1555.2200
  CSER.JSER  845.2500
  CSER.INV  6035.3470   // EST
  JADM.CADM  84797.0448   // EST
  JAGR.CAGR  46005.8642   // EST
  JAGR.XAGR  457.8100
  JIND.CFOOD  51645.0131   // EST
  JIND.COTHIND  100140.0277   // EST
  JIND.XFOOD  26220.0300
  JIND.XOTHIND  4040.6900
  JSER.CSER  86846.7133   // EST
  JSER.XSER  15.6800
  CAP.JADM  21672.9798   // EST
  CAP.JAGR  6860.8561   // EST
  CAP.JIND  18100.6277   // EST
  CAP.JSER  10672.6210   // EST
  LAND.JADM  43157.1883   // EST
  LAND.JAGR  13661.9543   // EST
  LAND.JIND  36043.5994   // EST
  LAND.JSER  21252.2837   // EST
  SK.JADM  5958.7854
  SK.JAGR  5334.2380
  SK.JIND  6143.2325
  SK.JSER  9053.6957
  USK.JADM  7818.7531
  USK.JAGR  6999.2602
  USK.JIND  8060.7732
  USK.JSER  11879.7048
  INV.FIRM  37476.8900   // EST
  INV.GVT  -62130.4279   // EST
  INV.HRP  15018.0231
  INV.HRR  38275.2798   // EST
  INV.HUP  16106.8079
  INV.HUR  25553.4215
  INV.ROW  -7766.4853   // EST
  VSTK.INV  2180.0399   // EST
  XAGR.ROW  1209.0771   // EST
  XFOOD.ROW  27024.9866   // EST
  XOTHIND.ROW  4344.0114   // EST
  XSER.ROW  1292.7421   // EST
/;

PARAMETER CHKDIF(AC) "Row minus column totals";
CHKDIF(AC) = SUM(ACJ, SAM(AC,ACJ)) - SUM(ACJ, SAM(ACJ,AC));
ABORT$(SMAX(AC, ABS(CHKDIF(AC))) > 0.01) "SAM NOT BALANCED", CHKDIF;

* =====================================================================
* SECTION 3: DATA-COMPLETION ASSUMPTIONS (documentation; already
* embedded in the matrix above; edit and rebalance if replacing EST)
* =====================================================================
SCALAR SERSHARE "Services share of household consumption (E4)" / 0.30 /;
PARAMETER INVSH(I) "Investment basket value shares (E8)"
/ CAGR 0.05, CFOOD 0.10, COTHIND 0.75, CSER 0.10, CADM 0.00 /;

* =====================================================================
* SECTION 4: ELASTICITIES (PEP-1-t V2.1 defaults; VAL_PAR.xls)
* =====================================================================
PARAMETERS
  sigma_VA(J), sigma_LD(J), sigma_KD(J), sigma_XT(J)
  sigma_M(I), sigma_XD(I), frisch(H)
  rho_VA(J), rho_LD(J), rho_KD(J), rho_XT(J), rho_M(I), rho_X(I);
sigma_VA(J)=1.5; sigma_LD(J)=0.8; sigma_KD(J)=0.8; sigma_XT(J)=2.0;
sigma_M(I)=2.0;  sigma_XD(I)=2.0; frisch(H)=-1.5;
* Elasticity robustness sets (Supplementary Table A12; Section 5.4)
IF(ELAST EQ 1, sigma_VA(J)=0.8; sigma_M(I)=1.2; sigma_XD(I)=1.2; );
IF(ELAST EQ 3, sigma_VA(J)=2.5; sigma_M(I)=3.5; sigma_XD(I)=3.5; );
rho_VA(J)=(1-sigma_VA(J))/sigma_VA(J);
rho_LD(J)=(1-sigma_LD(J))/sigma_LD(J);
rho_KD(J)=(1-sigma_KD(J))/sigma_KD(J);
rho_XT(J)=(1+sigma_XT(J))/sigma_XT(J);
rho_M(I) =(1-sigma_M(I))/sigma_M(I);
rho_X(I) =(1+sigma_XD(I))/sigma_XD(I);

SCALARS
  ALPHAFDI  "TFP linkage coefficient on FDI share (S5.1)"      / 0.15 /
  ALPHAHK   "TFP linkage coefficient on human capital (S5.1)"  / 0.30 /
  FDISH0    "Base-year FDI share of GDP"                       / 0.010 /
  delta_cap "Depreciation rate, produced capital"   / 0.03 /
  sigma_INV "Investment allocation elasticity"      / 2.0  /
  gworld    "World export demand growth"            / 0.030 /
  PCOBS0    "Official FY2019 per capita GDP (USD)"  / 1856 /
  UMICTH    "Upper-middle-income threshold (USD)"   / 4046 /
  HICTH     "High-income threshold, Plan target"    / 12500 /;
* S5.2 sensitivity sweep: joint scaling of the linkage coefficients
ALPHAFDI = ALPHAFDI*TFPSCALE;
ALPHAHK  = ALPHAHK*TFPSCALE;

* =====================================================================
* SECTION 5: CALIBRATION (base year; all prices = 1)
* =====================================================================
PARAMETERS
  XST0(J), TIP0(J), ttip(J), LD0(L,J), TIW0(L,J), ttiw(L,J)
  KD0(K,J), TIK0(K,J), ttik(K,J), LDC0(J), KDC0(J), VA0(J), CI0(J)
  v(J), io(J), aij(I,J)
  beta_LD(L,J), B_LD(J), beta_KD(K,J), B_KD(J), beta_VA(J), B_VA(J)
  XS0(J,I), beta_XT(J,I), B_XT(J)
  DS0(I), EX0(I), TIX0(I), ttix(I), XSC0(I), beta_X(I), B_X(I)
  IM0(I), DD0(I), Q0(I), beta_M(I), B_M(I)
  C0(I,H), CTH0(H), gamma(I,H), CMIN0(I,H)
  CG0(I), INVD0(I), VSTK0(I), DIT0(I)
  lamWL(H,L), lamRK(H,K), lamRKrow(K)
  YH0(H), TDH0(H), ttdh(H), SH0(H), sh1(H)
  TRrowh0(H), TRhrow(H), TRhgvt0(H), SAMHF(H)
  YF0, TDF0, ttdf, SF0, TRF0GVT, TRFROW0, TRGROW0, TRGVROW0
  TIWT0, TIKT0, TIPT0, TIXT0, YG0, G0, SG0, SROW0
  GFCF0, IT0, IND0(J), phi(J), LS0(L), POP0
  PWX0(I), PWM0(I);

XST0(J)   = SUM(ACJ, SAM(J,ACJ));
TIP0(J)   = SAM('GVT',J);
ttip(J)   = TIP0(J)/(XST0(J)-TIP0(J));
LD0(L,J)  = SAM(L,J);
TIW0('USK',J) = SAM('TUSK',J);   TIW0('SK',J)  = SAM('TSK',J);
KD0(K,J)  = SAM(K,J);
TIK0('CAP',J) = SAM('TCAP',J);   TIK0('LAND',J)= SAM('TLAND',J);
ttiw(L,J)$LD0(L,J) = TIW0(L,J)/LD0(L,J);
ttik(K,J)$KD0(K,J) = TIK0(K,J)/KD0(K,J);
LDC0(J)   = SUM(L, (1+ttiw(L,J))*LD0(L,J));
KDC0(J)   = SUM(K, (1+ttik(K,J))*KD0(K,J));
VA0(J)    = LDC0(J)+KDC0(J);
aij(I,J)  = SAM(I,J);
CI0(J)    = SUM(I, aij(I,J));
aij(I,J)$CI0(J) = aij(I,J)/CI0(J);
v(J)      = VA0(J)/XST0(J);
io(J)     = CI0(J)/XST0(J);

beta_LD(L,J)$LD0(L,J) = (1+ttiw(L,J))*LD0(L,J)**(rho_LD(J)+1);
beta_LD(L,J)$LD0(L,J) = beta_LD(L,J)
   /SUM(LL$LD0(LL,J), (1+ttiw(LL,J))*LD0(LL,J)**(rho_LD(J)+1));
B_LD(J)   = LDC0(J)/(SUM(L$LD0(L,J),
            beta_LD(L,J)*LD0(L,J)**(-rho_LD(J))))**(-1/rho_LD(J));
beta_KD(K,J)$KD0(K,J) = (1+ttik(K,J))*KD0(K,J)**(rho_KD(J)+1);
beta_KD(K,J)$KD0(K,J) = beta_KD(K,J)
   /SUM(KK$KD0(KK,J), (1+ttik(KK,J))*KD0(KK,J)**(rho_KD(J)+1));
B_KD(J)   = KDC0(J)/(SUM(K$KD0(K,J),
            beta_KD(K,J)*KD0(K,J)**(-rho_KD(J))))**(-1/rho_KD(J));
beta_VA(J)= LDC0(J)**(rho_VA(J)+1)
           /(LDC0(J)**(rho_VA(J)+1)+KDC0(J)**(rho_VA(J)+1));
B_VA(J)   = VA0(J)/(beta_VA(J)*LDC0(J)**(-rho_VA(J))
           +(1-beta_VA(J))*KDC0(J)**(-rho_VA(J)))**(-1/rho_VA(J));

XS0(J,I)  = SAM(J,I) + SUM(XX$MXI(XX,I), SAM(J,XX));
beta_XT(J,I)$XS0(J,I) = XS0(J,I)**(1-rho_XT(J));
beta_XT(J,I)$XS0(J,I) = beta_XT(J,I)
   /SUM(II$XS0(J,II), XS0(J,II)**(1-rho_XT(J)));
B_XT(J)   = XST0(J)
   /(SUM(I$XS0(J,I), beta_XT(J,I)*XS0(J,I)**rho_XT(J)))**(1/rho_XT(J));

DS0(I)    = SUM(J, SAM(J,I));
EX0(I)    = SUM((J,XX)$MXI(XX,I), SAM(J,XX));
TIX0(I)   = SUM(XX$MXI(XX,I), SAM('GVT',XX));
ttix(I)$EX0(I) = TIX0(I)/EX0(I);
XSC0(I)   = DS0(I)+EX0(I);
beta_X(I)$EX0(I) = EX0(I)**(1-rho_X(I))
   /(EX0(I)**(1-rho_X(I))+DS0(I)**(1-rho_X(I)));
B_X(I)$EX0(I) = XSC0(I)/(beta_X(I)*EX0(I)**rho_X(I)
   +(1-beta_X(I))*DS0(I)**rho_X(I))**(1/rho_X(I));

IM0(I)    = SAM('ROW',I);
DD0(I)    = DS0(I);
Q0(I)     = DD0(I)+IM0(I);
beta_M(I)$IM0(I) = IM0(I)**(rho_M(I)+1)
   /(IM0(I)**(rho_M(I)+1)+DD0(I)**(rho_M(I)+1));
B_M(I)$IM0(I) = Q0(I)/(beta_M(I)*IM0(I)**(-rho_M(I))
   +(1-beta_M(I))*DD0(I)**(-rho_M(I)))**(-1/rho_M(I));

C0(I,H)   = SAM(I,H);
CTH0(H)   = SUM(I, C0(I,H));
gamma(I,H)= C0(I,H)/CTH0(H);
CMIN0(I,H)= C0(I,H)*(1+1/frisch(H));
CG0(I)    = SAM(I,'GVT');
INVD0(I)  = SAM(I,'INV');
VSTK0(I)  = SAM(I,'VSTK');
DIT0(I)   = SUM(J, SAM(I,J));

lamWL(H,L)= SAM(H,L)/SUM(HH, SAM(HH,L));
lamRK(H,K)= SAM(H,K)/SUM(ACJ, SAM(ACJ,K));
lamRKrow(K)= SAM('ROW',K)/SUM(ACJ, SAM(ACJ,K));
YH0(H)    = SUM(ACJ, SAM(H,ACJ));
TDH0(H)   = SAM('TD',H);
ttdh(H)   = TDH0(H)/YH0(H);
SH0(H)    = SAM('INV',H);
sh1(H)    = SH0(H)/(YH0(H)-TDH0(H));
TRrowh0(H)= SAM(H,'ROW');
TRhrow(H) = SAM('ROW',H)/(YH0(H)-TDH0(H));
TRhgvt0(H)= SAM(H,'GVT');
YF0       = SUM(ACJ, SAM('FIRM',ACJ));
TDF0      = SAM('TD','FIRM');
ttdf      = TDF0/YF0;
SAMHF(H)  = SAM(H,'FIRM')/(YF0-TDF0);
SF0       = SAM('INV','FIRM');
TRF0GVT   = SAM('FIRM','GVT');
TRFROW0   = SAM('FIRM','ROW');
TRGROW0   = SAM('GVT','ROW');
TRGVROW0  = SAM('ROW','GVT');
TIWT0     = SUM((L,J), TIW0(L,J));
TIKT0     = SUM((K,J), TIK0(K,J));
TIPT0     = SUM(J, TIP0(J));
TIXT0     = SUM(I, TIX0(I));
YG0       = SUM(ACJ, SAM('GVT',ACJ));
G0        = SUM(I, CG0(I));
SG0       = SAM('INV','GVT');
SROW0     = SAM('INV','ROW');
GFCF0     = SUM(I, INVD0(I));
IT0       = GFCF0 + SUM(I, VSTK0(I));
LS0(L)    = SUM(J, LD0(L,J));
POP0      = 165.5;
PWX0(I)   = 1+ttix(I);
PWM0(I)   = 1;
IND0(J)   = GFCF0*(delta_cap+0.05)*KD0('CAP',J)
           /SUM(JJ, (delta_cap+0.05)*KD0('CAP',JJ));
phi(J)    = IND0(J)/KD0('CAP',J);
DISPLAY XST0, VA0, YG0, SG0, SROW0, GFCF0, LS0;

* Period-updated exogenous states (recursive dynamics)
PARAMETERS
  KSJ(K,J) "Installed capital"
  LSS(L)   "Labour supply"
  AJP(J)   "Sectoral TFP level"
  EXD0P(I) "World demand scale"
  CG0P(I)  "Real gvt consumption"
  VSTK0P(I)"Real inventories"
  TRH0P(H) "Real gvt-hh transfers"
  TRF0P    "Firm income (real)"
  TRFROW0P "Firm income from ROW"
  REMH0P(H)"Real remittances"
  KDC0P(J) "Composite capital"
  CMIN0P(I,H) "LES floors";

SCALARS SROWP "Foreign savings",
TDFAC "Direct tax scale",
IRP "Interest rate";

* =====================================================================
* SECTION 6: VARIABLES AND EQUATIONS
* =====================================================================
POSITIVE VARIABLES
  XST(J), VA(J), CI(J), LDC(J), LD(L,J), DI(I,J)
  XS(J,I), XSC(I), DS(I), EX(I), IM(I), DD(I), Q(I)
  C(I,H), CTH(H), CG(I), INVD(I), DIT(I)
  W(L), WC(J), RC(J), R(K,J), PVA(J), PCI(J), PP(J), PT(J)
  PDC(I), PD(I), PE(I), PEFOB(I), PM(I), PC(I)
  PIXCON, PIXINV, PIXGVT
  YH(H), YDH(H), SH(H), TDH(H), YF, YDF, SF, TDF
  YG, TDHT, TDFT, TIWT, TIKT, TIPT, TIXT
  IT, GFCF, INDJ(J), U(J)
  GDPBP, GDPMP, GDPMPREAL;
VARIABLES SG, CAB, LEON, OBJ;

EQUATIONS
  EQ1(J), EQ2(J), EQ3(J), EQ4(J), EQ5(J), EQ6(L,J), EQ7(J), EQ8(K,J), EQ9(I,J), EQ10(H), EQ35(H), EQ14(H), EQ16(H), EQ15(H), EQ17, EQ36, EQ20, EQ21, EQ24, EQ25, EQ27, EQ28, EQ29, EQ33, EQ22, EQ43, EQ46, EQ52(I,H), EQ57(I), EQ53, EQ56(I), EQ58(I), EQ61(J,I), EQ70(J), EQ75(I), EQ62(I), EQ63(I), EQ71(I), EQ76(I), EQ64(I), EQ77(I), EQ65(I), EQ66(I), EQ91(I), EQ92(I), EQ67(J), EQ68(J), EQ69(J), EQ79(I), EQ80(I), EQ82, EQ83, EQ85, EQ86(I1), EQ87(L), EQ89, EQ109(J), EQ90(J), EQ93, EQ94, EQ100, WALRAS, OBJECTIVE;

* --- Production block ---
EQ1(J)..  VA(J) =E= v(J)*XST(J);
EQ2(J)..  CI(J) =E= io(J)*XST(J);
EQ3(J)..  VA(J) =E= AJP(J)*B_VA(J)*(beta_VA(J)*LDC(J)**(-rho_VA(J))
          +(1-beta_VA(J))*KDC0P(J)**(-rho_VA(J)))**(-1/rho_VA(J));
EQ4(J)..  LDC(J) =E= (beta_VA(J)/(1-beta_VA(J))*RC(J)/WC(J))**sigma_VA(J)
          *KDC0P(J);
EQ5(J)..  PVA(J)*VA(J) =E= WC(J)*LDC(J)+RC(J)*KDC0P(J);
EQ6(L,J)$LD0(L,J).. LD(L,J) =E= (beta_LD(L,J)*WC(J)/(W(L)*(1+ttiw(L,J))))
          **sigma_LD(J)*B_LD(J)**(sigma_LD(J)-1)*LDC(J);
EQ7(J)..  WC(J)*LDC(J) =E= SUM(L$LD0(L,J), W(L)*(1+ttiw(L,J))*LD(L,J));
EQ8(K,J)$KD0(K,J).. R(K,J)*(1+ttik(K,J)) =E= RC(J)*beta_KD(K,J)
          *B_KD(J)**(-rho_KD(J))*(KDC0P(J)/KSJ(K,J))**(1+rho_KD(J));
EQ9(I,J).. DI(I,J) =E= aij(I,J)*CI(J);

* --- Households ---
EQ10(H).. YH(H) =E= SUM(L, lamWL(H,L)*W(L)*SUM(J$LD0(L,J), LD(L,J)))
          +SUM(K, lamRK(H,K)*SUM(J$KD0(K,J), R(K,J)*KSJ(K,J)))
          +PIXCON*(TRH0P(H)+REMH0P(H))+(YF-TDF)*SAMHF(H);
EQ35(H).. TDH(H) =E= TDFAC*ttdh(H)*YH(H);
EQ14(H).. YDH(H) =E= YH(H)-TDH(H);
EQ16(H).. SH(H) =E= sh1(H)*YDH(H);
EQ15(H).. CTH(H) =E= YDH(H)-SH(H)-TRhrow(H)*YDH(H);

* --- Firms ---
EQ17..    YF =E= PIXCON*TRF0P;
EQ36..    TDF =E= TDFAC*ttdf*YF;
EQ20..    YDF =E= (YF-TDF)*(1-SUM(H, SAMHF(H)));
EQ21..    SF =E= YDF;

* --- Government ---
EQ24..    TDHT =E= SUM(H, TDH(H));
EQ25..    TDFT =E= TDF;
EQ27..    TIWT =E= SUM((L,J)$LD0(L,J), ttiw(L,J)*W(L)*LD(L,J));
EQ28..    TIKT =E= SUM((K,J)$KD0(K,J), ttik(K,J)*R(K,J)*KSJ(K,J));
EQ29..    TIPT =E= SUM(J, ttip(J)*PP(J)*XST(J));
EQ33..    TIXT =E= SUM(I$EX0(I), ttix(I)*PE(I)*EX(I));
EQ22..    YG =E= TDHT+TDFT+TIWT+TIKT+TIPT+TIXT+PIXCON*TRGROW0;
EQ43..    SG =E= YG-SUM(I, PC(I)*CG(I))
          -PIXCON*(SUM(H, TRH0P(H))+TRF0GVT+TRGVROW0);

* --- Rest of the world (current account, reporting identity) ---
EQ46..    CAB =E= SUM(I$IM0(I), PM(I)*IM(I))
          +SUM(K, lamRKrow(K)*SUM(J$KD0(K,J), R(K,J)*KSJ(K,J)))
          +SUM(H, TRhrow(H)*YDH(H))+PIXCON*TRGVROW0
          -SUM(I$EX0(I), PEFOB(I)*EX(I))
          -PIXCON*(SUM(H, REMH0P(H))+TRFROW0P+TRGROW0)-SROWP;

* --- Final demand ---
EQ52(I,H).. PC(I)*C(I,H) =E= PC(I)*CMIN0P(I,H)
          +gamma(I,H)*(CTH(H)-SUM(II, PC(II)*CMIN0P(II,H)));
EQ57(I).. CG(I) =E= CG0P(I);
EQ53..    GFCF =E= IT-SUM(I, PC(I)*VSTK0P(I));
EQ56(I)$INVSH(I).. PC(I)*INVD(I) =E= INVSH(I)*GFCF;
EQ58(I).. DIT(I) =E= SUM(J, DI(I,J));

* --- Production allocation and trade ---
EQ61(J,I)$XS0(J,I).. XS(J,I) =E= XST(J)
          *(PDC(I)/(PT(J)*B_XT(J)**rho_XT(J)*beta_XT(J,I)))**sigma_XT(J);
EQ70(J).. PT(J)*XST(J) =E= SUM(I$XS0(J,I), PDC(I)*XS(J,I));
EQ75(I).. XSC(I) =E= SUM(J$XS0(J,I), XS(J,I));
EQ62(I)$EX0(I).. XSC(I) =E= B_X(I)*(beta_X(I)*EX(I)**rho_X(I)
          +(1-beta_X(I))*DS(I)**rho_X(I))**(1/rho_X(I));
EQ63(I)$EX0(I).. EX(I) =E= ((1-beta_X(I))/beta_X(I)*PE(I)/PD(I))
          **sigma_XD(I)*DS(I);
EQ71(I)$(NOT EX0(I)).. DS(I) =E= XSC(I);
EQ76(I).. PDC(I)*XSC(I) =E= PD(I)*DS(I)+(PE(I)*EX(I))$EX0(I);
EQ64(I)$EX0(I).. EX(I) =E= EXD0P(I)*(PWX0(I)/PEFOB(I))**sigma_XD(I);
EQ77(I)$EX0(I).. PEFOB(I) =E= PE(I)*(1+ttix(I));
EQ65(I)$IM0(I).. Q(I) =E= B_M(I)*(beta_M(I)*IM(I)**(-rho_M(I))
          +(1-beta_M(I))*DD(I)**(-rho_M(I)))**(-1/rho_M(I));
EQ66(I)$IM0(I).. IM(I) =E= (beta_M(I)/(1-beta_M(I))*PD(I)/PM(I))
          **sigma_M(I)*DD(I);
EQ91(I)$(NOT IM0(I)).. Q(I) =E= DD(I);
EQ92(I).. DS(I) =E= DD(I);

* --- Prices ---
EQ67(J).. PP(J)*XST(J) =E= PVA(J)*VA(J)+PCI(J)*CI(J);
EQ68(J).. PT(J) =E= PP(J)*(1+ttip(J));
EQ69(J).. PCI(J) =E= SUM(I, aij(I,J)*PC(I));
EQ79(I).. PM(I) =E= PWM0(I);
EQ80(I).. PC(I)*Q(I) =E= PD(I)*DD(I)+(PM(I)*IM(I))$IM0(I);
EQ82..    PIXCON =E= SUM((I,H), PC(I)*C0(I,H))/SUM((I,H), C0(I,H));
EQ83..    PIXINV =E= SUM(I$INVD0(I), PC(I)*INVD0(I))/GFCF0;
EQ85..    PIXGVT =E= SUM(I$CG0(I), PC(I)*CG0(I))/G0;

* --- Equilibrium ---
EQ86(I1).. Q(I1) =E= SUM(H, C(I1,H))+CG(I1)+INVD(I1)+DIT(I1)+VSTK0P(I1);
EQ87(L).. LSS(L) =E= SUM(J$LD0(L,J), LD(L,J));
EQ89..    IT =E= SUM(H, SH(H))+SF+SG+SROWP;
EQ109(J).. U(J) =E= PIXINV*(delta_cap+IRP);
EQ90(J).. INDJ(J) =E= (GFCF/PIXINV)
          *phi(J)*(R('CAP',J)/U(J))**sigma_INV*KSJ('CAP',J)
          /SUM(JJ, phi(JJ)*(R('CAP',JJ)/U(JJ))**sigma_INV*KSJ('CAP',JJ));

* --- GDP identities ---
EQ93..    GDPBP =E= SUM(J, PVA(J)*VA(J))+TIPT;
EQ94..    GDPMP =E= GDPBP+TIXT;
EQ100..   GDPMPREAL =E= GDPMP/PIXCON;

* --- Walras verification and objective ---
WALRAS..  LEON =E= Q('CAGR')-SUM(H, C('CAGR',H))-CG('CAGR')
          -INVD('CAGR')-DIT('CAGR')-VSTK0P('CAGR');
OBJECTIVE.. OBJ =E= 1;

MODEL DYCGE "PEP-based recursive-dynamic CGE, Bangladesh" / ALL /;
DYCGE.HOLDFIXED = 1;

* =====================================================================
* SECTION 7: SCENARIO PATHS AND RECURSIVE-DYNAMIC LOOP
* =====================================================================
PARAMETERS
  gpop(TIME), glab(TIME), nn(TIME)
  tdpath(TIME), irpath(TIME), fspath(TIME)
  FDISH(TIME) "FDI share of GDP path (S5.1 driver)"
  GHK(TIME)   "Human capital index growth path (S5.1 driver)"
  SHKTFP(TIME) "Downside TFP shocks"
  TFPADD(TIME) "Additive TFP term for the SL2 single lever run"
  GTFP0(J)    "Baseline sectoral TFP drift (S5.1)"
  GA(J)       "Sectoral TFP growth from S5.1 rule"
  POP(TIME), REP(*,TIME);
SCALAR FDISHL "Lagged FDI share (enters rule with one lag)";

* Baseline sectoral drifts: stylised calibration reproducing the
* aggregate 0.8 percent BAU path under BAU drivers; replace with
* historical sectoral averages as estimates become available.
GTFP0('JAGR')=0.003; GTFP0('JIND')=0.006; GTFP0('JSER')=0.005; GTFP0('JADM')=0.002;

nn(TIME)=0;
nn('1')=0.0255; nn('2')=0.018; nn('3')=0.020; nn('4')=0.020;
nn('5')=0.030;  nn('6')=0.030; nn('7')=0.030; nn('8')=0.010;
nn('9')=0.030;  nn('10')=0.025;

* BAU drivers (Supplementary Table A9)
gpop(TIME)  = MAX(0.010, 0.013-0.0001*(ORD(TIME)-1));
tdpath(TIME)= 1;
irpath(TIME)= 0.10;
fspath(TIME)= 1;
FDISH(TIME) = MIN(0.013, 0.010+0.0001*(ORD(TIME)-1));
GHK(TIME)   = 0.010;
SHKTFP(TIME)= 0;
TFPADD(TIME)= 0;
IF(SCEN EQ 2,
* Vision 2041 target drivers (Supplementary Table A10)
  gpop(TIME)  = MAX(0.000, 0.013*(1-(ORD(TIME)-1)/22));
  tdpath(TIME)= MIN(2, 1+(ORD(TIME)-1)/22);
  irpath(TIME)= MAX(0.075, 0.10-0.0011*(ORD(TIME)-1));
  fspath(TIME)= MIN(2.5, 1+0.068*(ORD(TIME)-1));
  FDISH(TIME) = MIN(0.040, 0.010+0.0018*(ORD(TIME)-1));
  GHK(TIME)   = MIN(0.020, 0.010+0.0005*(ORD(TIME)-1));
);
IF(SCEN EQ 3,
* Downside drivers (Supplementary Table A11)
  gpop(TIME)  = 0.013;
  FDISH(TIME) = 0.008;
  GHK(TIME)   = 0.008;
  SHKTFP(TIME)= 0.10*nn(TIME);
);
* -----------------------------------------------------------------
* Single lever decomposition runs SL1-SL5 (main text Table 6,
* Supplementary S7): BAU drivers with exactly one lever moved to
* its Vision 2041 target path. All other drivers stay at BAU.
* -----------------------------------------------------------------
IF(SCEN EQ 4,
* SL1: FDI inflows raised to 4 percent of GDP
  FDISH(TIME) = MIN(0.040, 0.010+0.0018*(ORD(TIME)-1));
);
IF(SCEN EQ 5,
* SL2: TFP growth raised to about 1.5 percent per year.
* GHK follows the target path; TFPADD supplies the residual so the
* aggregate S5.1 rule reaches ~1.5 percent with FDI held at BAU.
  GHK(TIME)    = MIN(0.020, 0.010+0.0005*(ORD(TIME)-1));
  TFPADD(TIME) = 0.004;
);
IF(SCEN EQ 6,
* SL3: population growth to near zero by 2041
  gpop(TIME) = MAX(0.000, 0.013*(1-(ORD(TIME)-1)/22));
);
IF(SCEN EQ 7,
* SL4: direct tax share doubled by 2041
  tdpath(TIME) = MIN(2, 1+(ORD(TIME)-1)/22);
);
IF(SCEN EQ 8,
* SL5: interest spread compressed toward 2.5 points
  irpath(TIME) = MAX(0.075, 0.10-0.0011*(ORD(TIME)-1));
);
IF(SCEN EQ 9,
* Partial reform: half of each target improvement (Section 5.4)
  gpop(TIME)  = MAX(0.0065, 0.013*(1-0.5*(ORD(TIME)-1)/22));
  tdpath(TIME)= MIN(1.5, 1+0.5*(ORD(TIME)-1)/22);
  irpath(TIME)= MAX(0.0875, 0.10-0.00055*(ORD(TIME)-1));
  fspath(TIME)= MIN(1.75, 1+0.034*(ORD(TIME)-1));
  FDISH(TIME) = MIN(0.025, 0.010+0.0009*(ORD(TIME)-1));
  GHK(TIME)   = MIN(0.015, 0.010+0.00025*(ORD(TIME)-1));
);
* -----------------------------------------------------------------
* UN fertility variants (Section 5.4). Applied after the scenario
* blocks so they compose with any scenario.
* -----------------------------------------------------------------
IF(FERT EQ 1, gpop(TIME) = MAX(0.000, gpop(TIME)-0.003); );
IF(FERT EQ 3, gpop(TIME) = gpop(TIME)+0.0025; );
glab(TIME) = gpop(TIME)+0.003;
POP('1')=POP0;
LOOP(TIME$(ORD(TIME) LT CARD(TIME)), POP(TIME+1)=POP(TIME)*(1+gpop(TIME)); );

* Initialise dynamic states at the base year
KSJ(K,J)=KD0(K,J);  LSS(L)=LS0(L);  AJP(J)=1;
EXD0P(I)=EX0(I);    CG0P(I)=CG0(I); VSTK0P(I)=VSTK0(I);
TRH0P(H)=TRhgvt0(H); TRF0P=YF0;     TRFROW0P=TRFROW0;
REMH0P(H)=TRrowh0(H); SROWP=SROW0;  TDFAC=1; IRP=0.10;
FDISHL=FDISH0;
KDC0P(J)=KDC0(J);   CMIN0P(I,H)=CMIN0(I,H);

* Initial levels (base-year replication values) and bounds
XST.L(J)=XST0(J); VA.L(J)=VA0(J); CI.L(J)=CI0(J); LDC.L(J)=LDC0(J);
LD.L(L,J)=LD0(L,J); DI.L(I,J)=aij(I,J)*CI0(J); XS.L(J,I)=XS0(J,I);
XSC.L(I)=XSC0(I); DS.L(I)=DS0(I); EX.L(I)=EX0(I); IM.L(I)=IM0(I);
DD.L(I)=DD0(I); Q.L(I)=Q0(I); C.L(I,H)=C0(I,H); CTH.L(H)=CTH0(H);
CG.L(I)=CG0(I); INVD.L(I)=INVD0(I); DIT.L(I)=DIT0(I);
W.L(L)=1; WC.L(J)=1; RC.L(J)=1; R.L(K,J)=1; PVA.L(J)=1; PCI.L(J)=1;
PP.L(J)=1/(1+ttip(J)); PT.L(J)=1; PDC.L(I)=1; PD.L(I)=1; PE.L(I)=1;
PEFOB.L(I)=1+ttix(I); PM.L(I)=1; PC.L(I)=1;
PIXCON.L=1; PIXINV.L=1; PIXGVT.L=1;
YH.L(H)=YH0(H); YDH.L(H)=YH0(H)-TDH0(H); SH.L(H)=SH0(H);
TDH.L(H)=TDH0(H); YF.L=YF0; TDF.L=TDF0; YDF.L=SF0; SF.L=SF0;
YG.L=YG0; SG.L=SG0; TDHT.L=SUM(H,TDH0(H)); TDFT.L=TDF0;
TIWT.L=TIWT0; TIKT.L=TIKT0; TIPT.L=TIPT0; TIXT.L=TIXT0;
IT.L=IT0; GFCF.L=GFCF0; INDJ.L(J)=IND0(J); U.L(J)=delta_cap+0.10;
GDPBP.L=SUM(J,VA0(J))+TIPT0; GDPMP.L=GDPBP.L+TIXT0;
GDPMPREAL.L=GDPMP.L; CAB.L=0; LEON.L=0; OBJ.L=1;
W.LO(L)=1E-6; PC.LO(I)=1E-6; PD.LO(I)=1E-6; PDC.LO(I)=1E-6;
PVA.LO(J)=1E-6; PT.LO(J)=1E-6; PIXCON.LO=1E-6; PIXINV.LO=1E-6;
XST.LO(J)=1E-6; Q.LO(I)=1E-6; DS.LO(I)=1E-6; DD.LO(I)=1E-6;
XSC.LO(I)=1E-6; CTH.LO(H)=1E-6; GFCF.LO=1E-6; IT.LO=1E-6;
LDC.LO(J)=1E-6; VA.LO(J)=1E-6;
EX.LO(I)$EX0(I)=1E-6; IM.LO(I)$IM0(I)=1E-6;
EX.FX(I)$(NOT EX0(I))=0; PE.FX(I)$(NOT EX0(I))=1;
PEFOB.FX(I)$(NOT EX0(I))=1; IM.FX(I)$(NOT IM0(I))=0;
INVD.FX(I)$(NOT INVSH(I))=0;

SCALARS GPC "per capita real growth", PCUSD "per capita income USD";
PCUSD=PCOBS0;

LOOP(TIME,
  IRP   = irpath(TIME);
  TDFAC = tdpath(TIME);
  SROWP = SROW0*fspath(TIME);
  SOLVE DYCGE USING NLP MAXIMIZING OBJ;
  ABORT$(DYCGE.MODELSTAT GT 2.5) "Period did not solve";

  REP('GDPMP',TIME)     = GDPMP.L;
  REP('GDPMPREAL',TIME) = GDPMPREAL.L;
  REP('PIXCON',TIME)    = PIXCON.L;
  REP('GFCF_GDP',TIME)  = GFCF.L/GDPMP.L;
  REP('SG',TIME)        = SG.L;
  REP('CAB',TIME)       = CAB.L;
  REP('LEON',TIME)      = LEON.L;
  REP('POP',TIME)       = POP(TIME);
  REP('TFPGR',TIME)     = SUM(J, VA0(J)*(GTFP0(J)+ALPHAFDI*(FDISHL-FDISH0)
                          +ALPHAHK*GHK(TIME)+TFPADD(TIME)
                          -SHKTFP(TIME)))/SUM(J, VA0(J));
  REP('FDISH',TIME)     = FDISH(TIME);
  IF(ORD(TIME) GT 1,
    GPC = REP('GDPMPREAL',TIME)/REP('GDPMPREAL',TIME-1)
          /(1+gpop(TIME-1))-1;
    PCUSD = PCUSD*(1+GPC);
  );
  REP('PCUSD',TIME) = PCUSD;

* update states for the next period
  KSJ('CAP',J) = (1-delta_cap)*KSJ('CAP',J)+INDJ.L(J);
  KDC0P(J) = B_KD(J)*(SUM(K$KD0(K,J),
             beta_KD(K,J)*KSJ(K,J)**(-rho_KD(J))))**(-1/rho_KD(J));
  LSS(L)   = LSS(L)*(1+glab(TIME));
* S5.1 partially endogenous TFP: gA(j,t)=g0(j)+0.15*[FDIsh(t-1)
* -FDIsh(0)]+0.30*gH(t), minus downside shocks where applicable
  GA(J)    = GTFP0(J)+ALPHAFDI*(FDISHL-FDISH0)+ALPHAHK*GHK(TIME)
             +TFPADD(TIME)-SHKTFP(TIME);
  AJP(J)   = AJP(J)*(1+GA(J));
  FDISHL   = FDISH(TIME);
  EXD0P(I) = EXD0P(I)*(1+gworld);
  CG0P(I)  = CG0P(I)*(1+gpop(TIME)+0.01);
  VSTK0P(I)= VSTK0P(I)*(1+0.03);
  TRH0P(H) = TRH0P(H)*(1+gpop(TIME)+0.01);
  REMH0P(H)= REMH0P(H)*(1+0.03);
  TRF0P    = TRF0P*(1+0.03);
  CMIN0P(I,H) = CMIN0P(I,H)*(1+gpop(TIME));
);

* =====================================================================
* SECTION 8: REPORTING
* =====================================================================
SCALARS YRUMIC "Year crossing UMIC" /0/, YRHIC "Year crossing HIC" /0/;
LOOP(TIME,
  IF(YRUMIC EQ 0 AND REP('PCUSD',TIME) GE UMICTH, YRUMIC=2018+ORD(TIME));
  IF(YRHIC  EQ 0 AND REP('PCUSD',TIME) GE HICTH,  YRHIC =2018+ORD(TIME));
);
SCALAR PC2041 "Per capita income in 2041 (period 23, USD)";
PC2041 = REP('PCUSD','23');
DISPLAY "Scenario codes: 1 BAU, 2 VISION, 3 DOWNSIDE, 4-8 SL1-SL5, 9 PARTIAL";
DISPLAY SCEN, ELAST, FERT, TFPSCALE;
DISPLAY REP, PC2041, YRUMIC, YRHIC;

FILE fres / DyCGE_results.csv /;
PUT fres;
PUT "year,scenario,GDPMP_musd,GDPMPREAL_musd,PCUSD,CPI,GFCF_share,SG_musd,CAB_musd,POP_mn,TFP_growth,FDI_share,LEON" /;
LOOP(TIME,
  PUT (2018+ORD(TIME)):4:0 "," SCEN:1:0 ","
      REP('GDPMP',TIME):12:2 "," REP('GDPMPREAL',TIME):12:2 ","
      REP('PCUSD',TIME):10:1 "," REP('PIXCON',TIME):8:4 ","
      REP('GFCF_GDP',TIME):8:4 "," REP('SG',TIME):12:2 ","
      REP('CAB',TIME):12:2 "," REP('POP',TIME):8:2 ","
      REP('TFPGR',TIME):8:5 "," REP('FDISH',TIME):8:4 ","
      REP('LEON',TIME):10:4 /;
);
PUTCLOSE fres;

* One-line run summary, appended across runs. The batch scripts in
* scripts/ write the header and collect all runs for main text
* Tables 6 to 8 and Supplementary Tables A12 and A8.
FILE fsum / DyCGE_summary.csv /;
fsum.ap = 1;
PUT fsum;
PUT SCEN:2:0 "," ELAST:1:0 "," FERT:1:0 "," TFPSCALE:4:2 ","
    PC2041:10:1 "," YRUMIC:6:0 "," YRHIC:6:0 /;
PUTCLOSE fsum;
* ============================== END ==================================
