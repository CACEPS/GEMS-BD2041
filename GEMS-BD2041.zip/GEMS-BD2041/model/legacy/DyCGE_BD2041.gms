* ======================================================

* DyCGE --- Bangladesh Economy Dynamic CGE Model

* GAMS 25.0.3 r65947 | CONOPT4 Solver | Base year: FY2018-2019

* Authors: [withheld for double-anonymous review]

* ======================================================

$TITLE Bangladesh DyCGE Model

* ============================================================

* SECTION 1: SET DEFINITIONS

* ============================================================

SET

J "All industries"

/ agr "Agriculture and other primary industries"

ind "Manufacturing and construction"

ser "Services"

adm "Public administration" /;

SET PUB(J) "Public industries" / adm /;

SET BUS(J) "Private industries" / agr, ind, ser /;

SET

I "All commodities"

/ agr "Agriculture and primary commodities"

food "Food and beverages"

othind "Other manufacturing and construction"

ser "Services"

adm "Public administration" /;

SET I1(I) "All commodities except agriculture"

/ food, othind, ser, adm /;

* Production factors

SET L "Labour categories" / usk "Unskilled workers", sk "Skilled
workers" /;

SET K "Capital categories" / cap "Capital", land "Land" /;

* Institutional agents

SET AG "All agents"

/ hrp "Poor rural households"

hup "Poor urban households"

hrr "Rich rural households"

hur "Rich urban households"

firm "Firms"

gvt "Government"

row "Rest of the world" /;

SET H(AG) "Households" / hrp, hup, hrr, hur /;

SET F(AG) "Firms" / firm /;

SET AGD(AG) "Domestic agents" / hrp, hup, hrr, hur, firm, gvt /;

SET AGNG(AG) "Non-government agents" / hrp, hup, hrr, hur, firm, row
/;

* Time periods (1*32 covers FY2019--FY2050)

SET TIME "Time periods" / 1*32 /;

SET T(TIME);

SET T1(TIME), T2(TIME), T3(TIME), T4(TIME);

T1(TIME) = YES$(ORD(TIME) EQ 1);

T2(TIME) = YES$(ORD(TIME) EQ 2);

T3(TIME) = YES$(ORD(TIME) EQ 3);

T4(TIME) = YES$(TIME.VAL EQ CARD(TIME));

ALIAS (J,JJ); ALIAS (I,IJ); ALIAS (AG,AGJ); ALIAS (H,HJ);

ALIAS (L,LJ); ALIAS (K,KJ);

* ============================================================

* SECTION 2: PARAMETERS

* ============================================================

PARAMETERS

* CES production elasticities (indexed in J)

sigma_KD(J) "Capital substitution elasticity"

sigma_LD(J) "Labour substitution elasticity"

sigma_VA(J) "Value-added CES elasticity"

sigma_XT(J) "Output transformation CET elasticity"

* Armington elasticities (indexed in I)

sigma_M(I) "Import demand elasticity"

sigma_XD(I) "Export demand elasticity"

* Household parameters

frisch(H) "Frisch parameter (marginal utility of income)"

* Depreciation rates

delta(K,J) "Capital depreciation rate"

* Investment demand elasticity

sigma_INV(K,J) "Investment demand elasticity"

* GDP growth parameters

n(TIME) "Exogenous GDP growth rate parameter"

nn(TIME) "Shock adjustment parameter"

* Forecast adjustment table

ROR(*) "Rate of change for adjustment variables";

* Assign elasticity values

sigma_KD(J) = 0.8;

sigma_LD(J) = 0.8;

sigma_VA(J) = 1.5;

sigma_XT(J) = 2.0;

sigma_M(I) = 2.0;

sigma_XD(I) = 2.0;

frisch(H) = -1.5;

delta("cap",J) = 0.03;

delta("land",J) = 0.00;

sigma_INV(K,J) = 2.0;

* GDP growth rates by period

n("1") = 0.07864; n("2") = 0.08153; n("3") = 0.03509; n("4") =
0.04864;

n("5") = 0.05864; n("6") = 0.06864; n("7") = 0.07864; n("8") =
0.08864;

n("9") = 0.07864; n("10") = 0.07064; n("11") = 0.07004;
n("12") = 0.06464;

n("13") = 0.05942; n("14") = 0.05642; n("15") = 0.05432;
n("16") = 0.05422;

n("17") = 0.05412; n("18") = 0.05042; n("19") = 0.05641;
n("20") = 0.05545;

n("21") = 0.05539; n("22") = 0.05533; n("23") = 0.05527;
n("24") = 0.05521;

n("25") = 0.05515; n("26") = 0.05509; n("27") = 0.05503;
n("28") = 0.05497;

n("29") = 0.05491; n("30") = 0.05485; n("31") = 0.05479;
n("32") = 0.05473;

* Shock (nn) parameters

nn("1") = 0.0255; nn("2") = 0.018; nn("3") = 0.020; nn("4") =
0.020;

nn("5") = 0.030; nn("6") = 0.030; nn("7") = 0.030; nn("8") =
0.010;

nn("9") = 0.030; nn("10")= 0.025;

* ============================================================
* S5.1 ENDOGENOUS PRODUCTIVITY LINKAGE (patched; see
* Supplementary Section S5.1 and model/tfp_linkage.gms)
* gA(j,t) = g0(j) + 0.15*[FDIshare(t-1)-FDIshare(0)] + 0.30*gH(t)
* A(J,TIME) is computed here as an exogenous-driver parameter and
* multiplies value added in EQ3.
* ============================================================
PARAMETERS
 G0(J)        "baseline sectoral TFP drift"
 FDISH(TIME)  "FDI inflows share of GDP by period"
 GHK(TIME)    "human capital index growth (demographic module)"
 GA(J,TIME)   "sectoral TFP growth"
 A(J,TIME)    "sectoral TFP level (base year = 1)";
SCALAR FDISH0 "base year FDI share" / 0.010 /;

* Baseline drifts: stylised calibration reproducing ~0.8% aggregate
* TFP growth under BAU drivers; replace with sectoral estimates as
* data allow (see Supplementary S5.1).
G0("agr")=0.003; G0("ind")=0.006; G0("ser")=0.005; G0("adm")=0.002;

* BAU driver paths (Supplementary Table A9). For the target and
* downside scenarios replace with the Table A10 / A11 paths:
*   target:   FDISH(TIME)=MIN(0.040, 0.010+0.0018*(ORD(TIME)-1));
*             GHK(TIME)  =MIN(0.020, 0.010+0.0005*(ORD(TIME)-1));
*   downside: FDISH(TIME)=0.008;  GHK(TIME)=0.008;
FDISH(TIME) = MIN(0.013, 0.010+0.0001*(ORD(TIME)-1));
GHK(TIME)   = 0.010;

GA(J,TIME)  = G0(J) + 0.15*(FDISH(TIME-1) - FDISH0)$(ORD(TIME) GT 1)
            + 0.30*GHK(TIME);
A(J,"1")    = 1;
LOOP(TIME$(ORD(TIME) LT CARD(TIME)),
  A(J,TIME+1) = A(J,TIME)*(1 + GA(J,TIME)); );

* ============================================================

* SECTION 3: VARIABLES

* ============================================================

VARIABLES

* Volume variables

C(I,H,TIME) "Consumption of commodity i by household h"

CG(I,TIME) "Public final consumption of commodity i"

CI(J,TIME) "Total intermediate consumption of industry j"

CMIN(I,H,TIME) "Minimum consumption of commodity i by household h"

CTH_REAL(H,TIME) "Real consumption budget of household h"

DD(I,TIME) "Domestic demand for locally-produced commodity i"

DI(I,J,TIME) "Intermediate consumption of commodity i by industry j"

DIT(I,TIME) "Total intermediate demand for commodity i"

DS(J,I,TIME) "Domestic supply of commodity i by industry j"

EX(J,I,TIME) "Quantity of product i exported by industry j"

EXD(I,TIME) "World demand for exports of product i"

G_REAL(TIME) "Real government expenditure on goods and services"

GDP_BP_REAL(TIME) "Real GDP at basic prices"

GDP_MP_REAL(TIME) "Real GDP at market prices"

GFCF_PRI_REAL(TIME) "Real private gross fixed capital formation"

GFCF_PUB_REAL(TIME) "Real public gross fixed capital formation"

IM(I,TIME) "Quantity of imports of product i"

IND(K,J,TIME) "Investment in capital k for industry j"

INV(I,TIME) "Total investment demand for commodity i (GFCF)"

INV_PRI(I,TIME) "Private investment demand for commodity i"

INV_PUB(I,TIME) "Public investment demand for commodity i"

KD(K,J,TIME) "Demand for capital k by industry j"

KDC(J,TIME) "Composite capital demand by industry j"

KS(K,TIME) "Supply of capital k"

LD(L,J,TIME) "Demand for labour l by industry j"

LDC(J,TIME) "Composite labour demand by industry j"

LS(L,TIME) "Supply of labour l"

MRGN(I,TIME) "Trade/transport margin demand for commodity i"

Q(I,TIME) "Quantity demanded of composite commodity i"

VA(J,TIME) "Value added of industry j"

VSTK(I,TIME) "Inventory change for commodity i"

XS(J,I,TIME) "Production of commodity i by industry j"

XST(J,TIME) "Total aggregate output of industry j"

* Price variables

e(TIME) "Exchange rate (domestic currency per unit foreign)"

IR(TIME) "Interest rate"

PPD(TIME) "Producer price deflator"

CPD(TIME) "Consumer price deflator"

IPI(TIME) "Industrial production index"

HPI(TIME) "House price index"

CoC(TIME) "Consumption credit"

Db(TIME) "Debt to GDP (BDT bn)"

DbA(TIME) "Bank debt to GDP"

DbAd(TIME) "Bank debt deflator"

UnEmPr(TIME) "Unemployment rate"

P(J,I,TIME) "Basic price of industry j product i"

PC(I,TIME) "Purchaser price of composite commodity i"

PCI(J,TIME) "Intermediate consumption price index of industry j"

PD(I,TIME) "Domestic price of local product i"

PE(I,TIME) "Export price of commodity i (excl. export taxes)"

PE_FOB(I,TIME) "FOB price of exported commodity i"

PIXCON(TIME) "Consumer price index (numeraire)"

PIXGDP(TIME) "GDP deflator"

PIXGVT(TIME) "Public expenditures price index"

PIXINV_PRI(TIME) "Private investment price index"

PIXINV_PUB(TIME) "Public investment price index"

PK_PRI(TIME) "Price of new private capital"

PK_PUB(TIME) "Price of new public capital"

PL(I,TIME) "Local price of product i (excl. product taxes)"

PM(I,TIME) "Import price of product i (incl. tariffs)"

PP(J,TIME) "Industry j unit cost"

PT(J,TIME) "Basic output price of industry j"

PVA(J,TIME) "Value-added price of industry j"

PWM(I,TIME) "World import price (foreign currency)"

PWX(I,TIME) "World export price (foreign currency)"

R(K,J,TIME) "Rental rate of capital k in industry j"

RC(J,TIME) "Composite capital rental rate of industry j"

RTI(K,J,TIME) "After-tax capital rental rate"

U(K,J,TIME) "User cost of capital k in industry j"

W(L,TIME) "Wage rate of labour l"

WC(J,TIME) "Composite wage rate of industry j"

WTI(L,J,TIME) "After-payroll-tax wage rate"

* Nominal variables

CAB(TIME) "Current account balance"

CTH(H,TIME) "Household h consumption budget"

G(TIME) "Government expenditure on goods and services"

GDP_BP(TIME) "GDP at basic prices"

GDP_FD(TIME) "GDP from final demand perspective"

GDP_IB(TIME) "GDP income-based"

GDP_MP(TIME) "GDP at market prices"

GFCF(TIME) "Gross fixed capital formation"

IT(TIME) "Total investment expenditures"

IT_PRI(TIME) "Private investment expenditures"

IT_PUB(TIME) "Public investment expenditures"

SF(F,TIME) "Savings of firms"

SG(TIME) "Government savings"

SH(H,TIME) "Household h savings"

SROW(TIME) "Rest-of-world savings"

TDF(F,TIME) "Business income taxes"

TDFT(TIME) "Total business income tax revenue"

TDH(H,TIME) "Household income taxes"

TDHT(TIME) "Total household income tax revenue"

TIC(I,TIME) "Indirect tax revenue on commodity i"

TICT(TIME) "Total indirect tax receipts"

TIK(K,J,TIME) "Capital tax revenue"

TIKT(TIME) "Total capital tax revenue"

TIM(I,TIME) "Import duty revenue on product i"

TIMT(TIME) "Total import duty revenue"

TIP(J,TIME) "Production tax revenue from industry j"

TIPT(TIME) "Total production tax revenue"

TIW(L,J,TIME) "Payroll tax revenue"

TIWT(TIME) "Total payroll tax revenue"

TIX(I,TIME) "Export tax revenue on product i"

TIXT(TIME) "Total export tax revenue"

TPRCTS(TIME) "Total tax revenue from products and imports"

TPRODN(TIME) "Total other production tax revenue"

TR(AG,AGJ,TIME) "Transfers from agent agj to agent ag"

YDF(F,TIME) "Firm f disposable income"

YDH(H,TIME) "Household h disposable income"

YF(F,TIME) "Firm f total income"

YFK(F,TIME) "Firm f capital income"

YFTR(F,TIME) "Firm f transfer income"

YG(TIME) "Total government income"

YGK(TIME) "Government capital income"

YGTR(TIME) "Government transfer income"

YH(H,TIME) "Household h total income"

YHK(H,TIME) "Household h capital income"

YHL(H,TIME) "Household h labour income"

YHTR(H,TIME) "Household h transfer income"

YROW(TIME) "Rest-of-world income"

* Rates and intercepts

sh0(H,TIME), sh1(H,TIME) "Savings function parameters"

tr0(H,TIME), tr1(H,TIME) "Transfer function parameters"

ttdf0(F,TIME), ttdf1(F,TIME) "Business income tax parameters"

ttdh0(H,TIME), ttdh1(H,TIME) "Household income tax parameters"

ttic(I,TIME) "Commodity tax rate"

ttik(K,J,TIME) "Capital tax rate"

ttim(I,TIME) "Import tariff rate"

ttip(J,TIME) "Production tax rate"

ttiw(L,J,TIME) "Payroll tax rate"

ttix(I,TIME) "Export tax rate"

* Walras verification

LEON(TIME) "Excess supply on last market (Walras)"

OBJ "Objective function (constant = 1)";

* ============================================================

* SECTION 4: EQUATIONS

* ============================================================

EQUATIONS

* Production block

EQ1(J,TIME) "Value added demand (Leontief)"

EQ2(J,TIME) "Total intermediate consumption demand (Leontief)"

EQ3(J,TIME) "CES between composite labour and capital"

EQ4(J,TIME) "Relative demand for composite labour and capital (CES)"

EQ5(J,TIME) "CES among labour categories"

EQ6(L,J,TIME) "Labour demand by type l (CES)"

EQ7(J,TIME) "CES among capital categories"

EQ8(K,J,TIME) "Capital demand by type k (CES)"

EQ9(I,J,TIME) "Intermediate input demand (Leontief)"

* Income and savings

EQ10(H,TIME) "Total household income"

EQ11(H,TIME) "Household labour income"

EQ12(H,TIME) "Household capital income"

EQ13(H,TIME) "Household transfer income"

EQ14(H,TIME) "Household disposable income"

EQ15(H,TIME) "Household consumption budget"

EQ16(H,TIME) "Household savings"

EQ17(F,TIME) "Firm total income"

EQ18(F,TIME) "Firm capital income"

EQ19(F,TIME) "Firm transfer income"

EQ20(F,TIME) "Firm disposable income"

EQ21(F,TIME) "Firm savings"

* Government

EQ22(TIME) "Total government income"

EQ23(TIME) "Government capital income"

EQ24(TIME) "Total household income tax revenue"

EQ25(TIME) "Total business income tax revenue"

EQ26(TIME) "Total other production tax revenue"

EQ27(TIME) "Total payroll tax receipts"

EQ28(TIME) "Total capital tax receipts"

EQ29(TIME) "Total production tax revenue"

EQ30(TIME) "Total product and import tax revenue"

EQ31(TIME) "Total indirect commodity tax receipts"

EQ32(TIME) "Total import duty revenue"

EQ33(TIME) "Total export tax revenue"

EQ34(TIME) "Government transfer income"

EQ35(H,TIME) "Household income tax"

EQ36(F,TIME) "Business income tax"

EQ37(L,J,TIME) "Payroll tax revenue"

EQ38(K,J,TIME) "Capital tax revenue"

EQ39(J,TIME) "Production tax revenue"

EQ40(I,TIME) "Indirect commodity tax revenue"

EQ41(I,TIME) "Import duty"

EQ42(I,TIME) "Export tax"

EQ43(TIME) "Government savings"

* Rest of world

EQ44(TIME) "ROW income"

EQ45(TIME) "ROW savings"

EQ46(TIME) "Current account balance"

* Transfers

EQ47(AGNG,H,TIME) "Transfers from h to agent agng"

EQ48(H,TIME) "Transfers from h to government"

EQ49(AG,F,TIME) "Transfers from firms"

EQ50(AGNG,TIME) "Public transfers"

EQ51(AGD,TIME) "Foreign transfers"

* Demand

EQ52(I,H,TIME) "Household consumption (LES)"

EQ53(TIME) "GFCF"

EQ54(I,TIME) "Private investment demand"

EQ55(I,TIME) "Public investment demand"

EQ56(I,TIME) "Total investment demand"

EQ57(I,TIME) "Government consumption demand"

EQ58(I,TIME) "Total intermediate demand"

EQ59(I,TIME) "Trade margin demand"

* International trade

EQ60(J,TIME) "CET output transformation"

EQ61(J,I,TIME) "Industry output by commodity (CET)"

EQ62(J,I,TIME) "CET between exports and domestic"

EQ63(J,I,TIME) "Export-domestic supply ratio"

EQ64(I,TIME) "World export demand"

EQ65(I,TIME) "CES between imports and domestic"

EQ66(I,TIME) "Import-domestic demand ratio"

* Prices

EQ67(J,TIME) "Unit cost"

EQ68(J,TIME) "Output price (incl. production tax)"

EQ69(J,TIME) "Intermediate input price index"

EQ70(J,TIME) "Value-added price"

EQ72(L,J,TIME) "After-payroll-tax wage rate"

EQ74(K,J,TIME) "After-capital-tax rental rate"

EQ75a(J,I,TIME) "Producer price = industry price (single product)"

EQ76(J,I,TIME) "Revenue split between export and domestic"

EQ77(I,TIME) "FOB export price"

EQ78(I,TIME) "Domestic price including taxes and margins"

EQ79(I,TIME) "Import price including tariffs and margins"

EQ80(I,TIME) "Composite commodity price"

EQ81(TIME) "GDP deflator (Fisher index)"

EQ82(TIME) "Consumer price index (Laspeyres)"

EQ83(TIME) "Private investment price index"

EQ84(TIME) "Public investment price index"

EQ85(TIME) "Government expenditure price index"

* Equilibrium

EQ86(I1,TIME) "Domestic absorption equilibrium"

EQ87(L,TIME) "Labour market clearing"

EQ88(K,TIME) "Capital market clearing"

EQ89(TIME) "Investment = savings"

EQ90(TIME) "Private investment equilibrium"

EQ91(I,TIME) "Domestic supply = demand"

EQ92(I,TIME) "Export supply = demand"

* GDP identities

EQ93(TIME) "GDP at basic prices"

EQ94(TIME) "GDP at market prices"

EQ95(TIME) "GDP income-based"

EQ96(TIME) "GDP final demand"

* Real variables

EQ97(H,TIME) "Real household consumption budget"

EQ98(TIME) "Real government expenditure"

EQ99(TIME) "Real GDP at basic prices"

EQ100(TIME) "Real GDP at market prices"

EQ101(TIME) "Real private GFCF"

EQ102(TIME) "Real public GFCF"

* Dynamic equations

EQ104(TIME) "Total public investment"

EQ105(TIME) "Total private investment"

EQ106(TIME) "Private capital price"

EQ107(TIME) "Public capital price"

EQ108(K,BUS,TIME) "Private investment demand"

EQ109a(K,BUS,TIME) "User cost of capital (private)"

EQ109b(K,PUB,TIME) "User cost of capital (public)"

WALRAS(TIME) "Walras law verification"

OBJECTIVE "Objective function";

* ============================================================

* SECTION 5: EQUATION SPECIFICATIONS

* ============================================================

* \-\-- Production Block \-\--

EQ1(J,T).. VA(J,T) =E= v(J)*XST(J,T);

EQ2(J,T).. CI(J,T) =E= io(J)*XST(J,T);

EQ3(J,T).. VA(J,T) =E= A(J,T)*B_VA(J)*{

[beta_VA(J)*LDC(J,T)**(-rho_VA(J))]$LDCO(J)

+[(1-beta_VA(J))*KDC(J,T)**(-rho_VA(J))]$KDCO(J)

}**(-1/rho_VA(J));

EQ4(J,T)$[LDCO(J) AND KDCO(J)].. LDC(J,T) =E=

{[beta_VA(J)/(1-beta_VA(J))]*[RC(J,T)/WC(J,T)]}**sigma_VA(J)*KDC(J,T);

EQ5(J,T)$LDCO(J).. LDC(J,T) =E= B_LD(J)*

SUM[L$LDO(L,J),
beta_LD(L,J)*LD(L,J,T)**(-rho_LD(J))]**(-1/rho_LD(J));

EQ6(L,J,T)$LDO(L,J).. LD(L,J,T) =E=

[beta_LD(L,J)*WC(J,T)/WTI(L,J,T)]**sigma_LD(J)

*B_LD(J)**(sigma_LD(J)-1)*LDC(J,T);

EQ7(J,T)$KDCO(J).. KDC(J,T) =E= B_KD(J)*

SUM[K$KDO(K,J),
beta_KD(K,J)*KD(K,J,T)**(-rho_KD(J))]**(-1/rho_KD(J));

EQ8(K,J,T)$KDO(K,J).. KD(K,J,T) =E=

[beta_KD(K,J)*RC(J,T)/RTI(K,J,T)]**sigma_KD(J)

*B_KD(J)**(sigma_KD(J)-1)*KDC(J,T);

EQ9(I,J,T).. DI(I,J,T) =E= aij(I,J)*CI(J,T);

* \-\-- Income and Savings \-\--

EQ10(H,T).. YH(H,T) =E= YHL(H,T)+YHK(H,T)+YHTR(H,T);

EQ11(H,T).. YHL(H,T) =E= SUM{L, lambda_WL(H,L)*W(L,T)

*SUM[J$LDO(L,J), LD(L,J,T)]};

EQ12(H,T).. YHK(H,T) =E= SUM{K, lambda_RK(H,K)

*SUM[J$KDO(K,J), R(K,J,T)*KD(K,J,T)]};

EQ13(H,T).. YHTR(H,T) =E= SUM[AG, TR(H,AG,T)];

EQ14(H,T).. YDH(H,T) =E= YH(H,T)-TDH(H,T)-TR("gvt",H,T);

EQ15(H,T).. CTH(H,T) =E= YDH(H,T)-SH(H,T)-SUM[AGNG, TR(AGNG,H,T)];

EQ16(H,T).. SH(H,T) =E= PIXCON(T)**eta*sh0(H,T)+sh1(H,T)*YDH(H,T);

* \-\-- Government \-\--

EQ22(T).. YG(T) =E=
YGK(T)+TDHT(T)+TDFT(T)+TPRODN(T)+TPRCTS(T)+YGTR(T);

EQ43(T).. SG(T) =E= YG(T)-SUM[AGNG, TR(AGNG,"gvt",T)]-G(T);

* \-\-- Equilibrium \-\--

EQ87(L,T).. LS(L,T) =E= SUM[J$LDO(L,J), LD(L,J,T)];

EQ88(K,T).. KS(K,T) =E= SUM[J$KDO(K,J), KD(K,J,T)];

EQ89(T).. IT(T) =E= SUM[H,SH(H,T)]+SUM[F,SF(F,T)]+SG(T)+SROW(T);

* \-\-- GDP Identities \-\--

EQ93(T).. GDP_BP(T) =E= SUM[J, PVA(J,T)*VA(J,T)]+TIPT(T);

EQ94(T).. GDP_MP(T) =E= GDP_BP(T)+TPRCTS(T);

EQ95(T).. GDP_IB(T) =E= SUM[(L,J)$LDO(L,J), W(L,T)*LD(L,J,T)]

+SUM[(K,J)$KDO(K,J), R(K,J,T)*KD(K,J,T)]+TPRODN(T)+TPRCTS(T);

* \-\-- Real Variables \-\--

EQ97(H,T).. CTH_REAL(H,T) =E= CTH(H,T)/PIXCON(T);

EQ98(T).. G_REAL(T) =E= G(T)/PIXGVT(T);

EQ99(T).. GDP_BP_REAL(T) =E= GDP_BP(T)/PIXGDP(T);

EQ100(T).. GDP_MP_REAL(T) =E= GDP_MP(T)/PIXCON(T);

EQ101(T).. GFCF_PRI_REAL(T) =E= IT_PRI(T)/PIXINV_PRI(T);

EQ102(T).. GFCF_PUB_REAL(T) =E= IT_PUB(T)/PIXINV_PUB(T);

* \-\-- Dynamic Investment \-\--

EQ104(T).. IT_PUB(T) =E= PK_PUB(T)*SUM[(K,PUB)$KDO(K,PUB),
IND(K,PUB,T)];

EQ105(T).. IT_PRI(T) =E= PK_PRI(T)*SUM[(K,BUS)$KDO(K,BUS),
IND(K,BUS,T)];

EQ108(K,BUS,T)$KDO(K,BUS).. IND(K,BUS,T) =E=

phi(K,BUS)*[R(K,BUS,T)/U(K,BUS,T)]**sigma_INV(K,BUS)*KD(K,BUS,T);

EQ109a(K,BUS,T)$KDO(K,BUS).. U(K,BUS,T) =E=
PK_PRI(T)*(delta(K,BUS)+IR(T));

EQ109b(K,PUB,T)$KDO(K,PUB).. U(K,PUB,T) =E=
PK_PUB(T)*(delta(K,PUB)+IR(T));

* \-\-- Walras Law and Objective \-\--

WALRAS(T).. LEON(T) =E= Q("agr",T)

-SUM[H, C("agr",H,T)]-CG("agr",T)

-INV("agr",T)-VSTK("agr",T)

-DIT("agr",T)-MRGN("agr",T);

OBJECTIVE.. OBJ =E= 1;

* ============================================================

* SECTION 6: MODEL SOLUTION

* ============================================================

OPTION NLP = CONOPT4;

MODEL DyCGE "Standard PEP Dynamic CGE Model v2.1 --- Bangladesh"
/ALL/;

DyCGE.HOLDFIXED = 1;

OPTION LIMROW=0, LIMCOL=0, SOLPRINT=OFF;

OPTION DECIMALS=2;

SOLVE DyCGE USING NLP MAXIMISING OBJ;

* ============================================================

* SECTION 7: MODEL STATISTICS (GAMS OUTPUT)

* ============================================================

* BLOCKS OF EQUATIONS: 109 SINGLE EQUATIONS: 378

* BLOCKS OF VARIABLES: 102 SINGLE VARIABLES: 378

* NON-ZERO ELEMENTS: 1,366 NON-LINEAR N-Z: 542

* DERIVATIVE POOL: 20 CONSTANT POOL: 172

* CODE LENGTH: 1,595

* SOLVE SUMMARY (Period 1 --- baseline):

* MODEL: DyCGE | TYPE: NLP | SOLVER: CONOPT4

* SOLVER STATUS: 1 (Normal Completion)

* MODEL STATUS: 2 (Locally Optimal)

* OBJECTIVE VALUE: 1.0000

* RESOURCE USAGE: 0.047 seconds

* SOLVE SUMMARY (Periods 24--32 --- downside/shock):

* SOLVER STATUS: 5 (Evaluation Interrupt)

* MODEL STATUS: 6 (Intermediate Infeasible)

* EVALUATION ERRORS: 3--4 (domain errors in CES functions)

* NOTE: Infeasibility from period 24 onward under extreme

* downside scenario reflects model constraint on

* feasible per-capita income growth under zero policy

* change assumption beyond 2042.

**Supplementary References**

Alam, M. K. (2014). Ocean/Blue economy for Bangladesh. In Proceedings of
International Workshop on Blue Economy (pp. 28--49). Ministry of Foreign
Affairs.

Aziz, A. (2020). Digital inclusion challenges in Bangladesh: The case of
the National ICT Policy. Contemporary South Asia, 28(3), 304--319.

Centre for Policy Dialogue (CPD). (2021). An analysis of the national
budget for FY2021--22.
https://cpd.org.bd/wp-content/uploads/2021/06/CPD-Budget-Analysis-FY2022.pdf

Department of Fisheries (DoF). (2016). National Fish Week 2016
compendium. Ministry of Fisheries and Livestock, Bangladesh.

Hasan, M., Le, T., & Hoque, A. (2021). How does financial literacy
impact on inclusive finance? Financial Innovation, 7(1), 1--23.

Macrotrends LLC. (n.d.). Bangladesh GDP growth rate [Historical
chart].
https://www.macrotrends.net/countries/BGD/bangladesh/gdp-growth-rate

Robinson, S., Cattaneo, A., & El-Said, M. (2001). Updating and
estimating a social accounting matrix using cross entropy methods.
Economic Systems Research, 13(1), 47--64.

: Note: The GAMS code represents the core DyCGE model structure
(skipped some sections). Full parameterisation, calibration files,
and SAM data tables are available from the authors upon
reasonable request. The model follows the PEP Standard CGE Framework
(Decaluwé, Lemelin, Robichaud & Maisonnave) adapted for
Bangladesh's dynamic multi-period context. GAMS v25.0.3; CONOPT4
solver; solved 2024-10-25.
