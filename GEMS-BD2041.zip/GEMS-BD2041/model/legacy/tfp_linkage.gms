* ======================================================
* Endogenous productivity linkage (reduced form), S5.1
* STATUS: integrated into DyCGE_BD2041.gms (search for
* "S5.1 ENDOGENOUS PRODUCTIVITY LINKAGE"). This file is kept
* as standalone documentation of the rule and its calibration.
* Calibration informed by the FDI spillover and human capital
* growth literatures (Borensztein, De Gregorio & Lee, 1998;
* Barro, 2001).
* ======================================================

PARAMETER
 G0(J)       "baseline sectoral TFP drift"
 FDISH(TIME) "FDI inflows share of GDP by period"
 GHK(TIME)   "human capital index growth (demographic module)"
 GA(J,TIME)  "sectoral TFP growth"
 A(J,TIME)   "sectoral TFP level (base year = 1)";
SCALAR FDISH0 "base year FDI share" / 0.010 /;

G0("agr")=0.003; G0("ind")=0.006; G0("ser")=0.005; G0("adm")=0.002;

* Scenario driver paths (Supplementary Tables A9 to A11)
* BAU:
FDISH(TIME) = MIN(0.013, 0.010+0.0001*(ORD(TIME)-1));
GHK(TIME)   = 0.010;
* target:   FDISH(TIME)=MIN(0.040, 0.010+0.0018*(ORD(TIME)-1));
*           GHK(TIME)  =MIN(0.020, 0.010+0.0005*(ORD(TIME)-1));
* downside: FDISH(TIME)=0.008;  GHK(TIME)=0.008;

GA(J,TIME) = G0(J) + 0.15*(FDISH(TIME-1) - FDISH0)$(ORD(TIME) GT 1)
           + 0.30*GHK(TIME);

* TFP level update (recursive)
A(J,"1") = 1;
LOOP(TIME$(ORD(TIME) LT CARD(TIME)),
  A(J,TIME+1) = A(J,TIME)*(1 + GA(J,TIME)); );

* EQ3 in the main model reads: VA(J,T) =E= A(J,T)*B_VA(J)*{...}
* BAU drivers reproduce ~0.8% aggregate TFP growth; target drivers
* ~1.5%. Recalibrate G0(J) if they do not.
